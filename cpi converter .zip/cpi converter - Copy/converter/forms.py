from django import forms
from .models import result

class resultform(forms.Form) :
	enrollment_no = forms.CharField(max_length=200)
	faculty_no = forms.CharField(max_length=200)
	
	