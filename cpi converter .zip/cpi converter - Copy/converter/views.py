from django.shortcuts import render
from .models import result
from .forms import resultform
from django.shortcuts import redirect
from django.shortcuts import render,get_object_or_404

# Create your views here.
class abc : 
	text = ''
	def result_form(request) :
		flag=True
		if request.method == "POST" :
			form = resultform(request.POST)
			if form.is_valid():
				text = form.cleaned_data['enrollment_no']
				text1 = form.cleaned_data['faculty_no']
				re3 = result.objects.filter(enrollment_no=text , faculty_no = text1)
				#re1 = re3
				if len(re3) == 0 :
					flag=False
				return render(request,'converter/result_form.html',{'form' : form , 're3' : re3,'flag':flag})
		else :
			form = resultform()
			return render(request,'converter/result_form.html',{'form' : form,'flag':flag})
	