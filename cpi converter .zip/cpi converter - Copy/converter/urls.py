from django.conf.urls import url
from .views import abc

urlpatterns = [
	#url(r'^$', views.result_list, name='result_list'),
	url(r'^$',abc.result_form, name='result_form'),
	#url(r'^result_detail/$',abc.result_detail, name='result_detail'),
]
