from django.apps import AppConfig


class ConverterConfig(AppConfig):
    name = 'converter'
